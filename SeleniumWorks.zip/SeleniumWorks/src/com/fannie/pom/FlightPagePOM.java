package com.fannie.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//page object model for selenium
public class FlightPagePOM {
	static private WebElement element;
	
	public static void  flyingFromTextBox(WebDriver driver, String Source){
		element = driver.findElement(By.id("flight-origin-hp-flight"));
		element.sendKeys(Source);
		
		//return element;
	}

	public static WebElement flyingToTextBox(WebDriver driver){
		element = driver.findElement(By.id("flight-destination-hp-flight"));
		
		return element;
	}

	public static  WebElement departingDate(WebDriver driver){
		driver.findElement(By.id("flight-departing-hp-flight")).click();
		driver.findElement(By.id("flight-departing-hp-flight")).clear();
		element = driver.findElement(By.id("flight-departing-hp-flight"));
		
		return element;
	}
	

	public static WebElement returningDate(WebDriver driver){
		driver.findElement(By.id("flight-returning-hp-flight")).click();
		driver.findElement(By.id("flight-returning-hp-flight")).clear();
		element = driver.findElement(By.id("flight-returning-hp-flight"));
	
		return element;
	}
	
	public static void  clickFlightTab(WebDriver driver){
		 driver.findElement(By.id("tab-flight-tab-hp")).click();
		
	}
	public static void  clickSearchBtn(WebDriver driver){
		 driver.findElement
		 (By.xpath("//*[@id='gcw-flights-form-hp-flight']/div[7]/label/button")).click();
		
	}
	
	
}
