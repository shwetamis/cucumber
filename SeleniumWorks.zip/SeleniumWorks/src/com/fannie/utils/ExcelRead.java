package com.fannie.utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelRead {

	
	public static void main(String[] args) throws IOException  {
		
		String path ="C:\\Users\\Huser\\Desktop\\sample (1).xlsx"; // path where excel is located
		
		String sheetName="Sheet1"; // sheet of the excel you will be working on
		
		FileInputStream excelFile = new FileInputStream(path);
		
		XSSFWorkbook excelWorkbook= new XSSFWorkbook(excelFile);
		
		XSSFSheet excelSheet = excelWorkbook.getSheet(sheetName);
		// for getting cell value
		XSSFCell cell= excelSheet.getRow(1).getCell(1);
		
		System.out.println("Value is " + cell.getStringCellValue());
		
		// for manipulation
		excelWorkbook.close();
	}
	
	public static XSSFSheet getSheet(String path, String sheetName){
		XSSFSheet sheet=null; // if you don't give value as null it will give error
		try {
			XSSFWorkbook workbook= new XSSFWorkbook(new FileInputStream(path) );
			 sheet = workbook.getSheet(sheetName);
			 System.out.println("My sheet name is "+  sheetName);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sheet;
		
	}
	
	
}
