package com.fannie.utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WaitTypes {
	WebDriver driver;
	//this is good for text elements, for buttons use visible invisible
	public WaitTypes(WebDriver driver){
		this.driver =driver;
	}
	public WebElement waitForElement(By locator, int timeout){
		try{
			WebDriverWait wait = new WebDriverWait(driver,10);
			WebElement element = wait.until(
				ExpectedConditions.visibilityOfElementLocated(locator)  
				  );
		  System.out.println("Element visible on site");
		  return element;
	     }
			catch(Exception e){
				System.out.println("Sorry Element not visible, timed out");
				}
		return null;
	}
	//For buttons as they don't have values to be sent
	public void clickWhenReady(By locator, int timeout){
		try{
			WebDriverWait wait = new WebDriverWait(driver,10);
			WebElement element = wait.until(
				ExpectedConditions.elementToBeClickable(locator)
				  );
		  System.out.println("Element available to click on site");
		
	     }
			catch(Exception e){
				System.out.println("Sorry Element not visible, timed out");
				}

	}
	
}