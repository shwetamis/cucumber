package com.fannie.basic;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BasicTest02 {
	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver;
		//String baseUrl="http://google.com";
		String baseUrl="https://sdettraining.litmos.com/home/Dashboard";
		//make sure you change the path manually to //.../// from /../
		System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chrome\\chromedriver_win32\\chromedriver.exe");
		
		//we want to test on chrome driver
		driver =new ChromeDriver();
			
		driver.get(baseUrl);
		driver.manage().window().maximize();
		//
		//driver.findElement(By.id("lst-ib")).sendKeys("best place to visit in VA");
		
		//driver.findElement(By.name("btng")).click();
		
	driver.findElement(By.id("472458")).click();
	
	
	//driver.findElement(By.id("inputEmail")).sendKeys("John");
	//Thread.sleep(3000);//sleep
		
		//Thread.sleep(2000);
	//driver.quit();
}		
		
	}

