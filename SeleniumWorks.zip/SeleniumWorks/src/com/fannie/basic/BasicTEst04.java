package com.fannie.basic;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BasicTEst04 {
public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver;
		String baseUrl="https://demostore.x-cart.com"; // go to this website
		//make sure you change the path manually to //.../// from /../
		System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chrome\\chromedriver_win32\\chromedriver.exe");	
		//we want to test on chrome driver
		driver =new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);// for managing timeouts her max timeouts is 10 secs
			
		driver.get(baseUrl);
		driver.manage().window().maximize();
		
//		driver.findElement(By.linkText("Shipping")).click();// click on shipping page on the website
//		
//		Thread.sleep(2000);// sleep for 2 secs and then click contact us page
//	
//		driver.findElement(By.partialLinkText("Contact")).click();
		
		//driver.findElement(By.tagName("a")).click(); ///failed case as there will be so many with anchor tah "a" so it doesn't know which one to pick from
		
	//driver.quit();
	}
}
