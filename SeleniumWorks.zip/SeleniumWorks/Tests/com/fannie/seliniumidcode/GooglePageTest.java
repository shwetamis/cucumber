package com.fannie.seliniumidcode;

import static org.junit.Assert.fail;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

//selenium generated code
//this prog generated through selenium IDE
public class GooglePageTest {

	 private WebDriver driver;
	  private String baseUrl;
	  
	  @Before
	  public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chrome\\chromedriver_win32\\chromedriver.exe");
	    driver = new ChromeDriver();
	    baseUrl = "https://www.google.com/";

	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	  }

	  @Test
	  public void testClassroom05() throws Exception {
	    driver.get(baseUrl + "/");
	    driver.findElement(By.id("lst-ib")).clear();
	    driver.findElement(By.id("lst-ib")).sendKeys("places near spain");
	    driver.findElement(By.id("_fZl")).click();
	    driver.findElement(By.id("_fZl")).click();
	    driver.findElement(By.linkText("10 Best Places to Visit in Spain (with Photos & Map) - Touropia")).click();
	  }

	  @After
	  public void tearDown() throws Exception {
		  Thread.sleep(2000);
	    driver.quit();
	    
	}

}
