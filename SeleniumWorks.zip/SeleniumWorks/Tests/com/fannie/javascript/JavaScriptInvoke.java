package com.fannie.javascript;

import static org.junit.Assert.*;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class JavaScriptInvoke {

private JavascriptExecutor jsExecutor;
private WebDriver driver;

	@Before
	  public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chrome\\chromedriver_win32\\chromedriver.exe");// this is the location where your driver is
	    driver = new ChromeDriver();
	    jsExecutor = (JavascriptExecutor) driver;
	
	    
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);//wait for 30 secs, if this is commented out the test fails as after login email page won't stay
	  }
	  @After
	  public void tearDown() throws Exception {
		  Thread.sleep(3000);
	  // driver.quit(); // quit the website after performing the function
	    
	} 

	@Test
	public void test() {
		jsExecutor.executeScript
		("window.location='http://naveenks.com/selenium/RegForm.html'");
		WebElement element = (WebElement) jsExecutor.executeScript("return document.getElementById('inputEmail')"); 
		// add cast as we want object of jsExecutor.executeScript to take method from Web element ( concept of polymorphism)
		//super class can be implemented and sub class have to be type casted
		// press f4 on any class and see the hierarchy
		element.sendKeys("hello@gmail.com");
	}

}
