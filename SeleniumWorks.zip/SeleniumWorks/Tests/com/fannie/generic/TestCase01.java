package com.fannie.generic;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestCase01 {

	private WebDriver driver;
	//String baseUrl="http://google.com";
	private String baseUrl;
	private GenericMethod1 gm1;
	@Before
	  public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chrome\\chromedriver_win32\\chromedriver.exe");
	    driver = new ChromeDriver();
	    gm1=new GenericMethod1(driver);
	    baseUrl = "http://naveenks.com/selenium/RegForm.html";
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);//wait for 30 secs
	  }
	  
	  @After
	  public void tearDown() throws Exception {
		  Thread.sleep(2000);
	    driver.quit(); // quit the website after performing the function
	    
	}
	  
	  @Test
	  public void test() throws InterruptedException{
		  driver.get(baseUrl);
		  WebElement inputElement = gm1.getElement("inputEmail","id");
		  inputElement.sendKeys("john@doe.com");
		  if(gm1.checkSingleFound("inputPassword","id")){
		  gm1.getElement("inputPassword","id").sendKeys("helloworld");
		  }
		  gm1.getElement("confirmPassword","id").sendKeys("hiworld");
		  
		  Thread.sleep(2000);
		  inputElement.clear();
		  inputElement.sendKeys("peter@england.com");
		  
		 // gm1.getElement("/html/body/div[1]/form/div[13]/div/input[1]","xpath").click();
		  gm1.getElement("/html/body/div[1]/form/div[13]/div/input[1]",Itype.XPATH).click();
	  }
}
