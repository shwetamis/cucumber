package com.fannie.testcase;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestCase02 {

		
		private WebDriver driver;
		  private String baseUrl;
		  
		  @Before
		  public void setUp() throws Exception {
			System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chrome\\chromedriver_win32\\chromedriver.exe");
		    driver = new ChromeDriver();
		    baseUrl = "https://www.google.com";

		    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		  }
		  
		  @After
		  public void tearDown() throws Exception {
			  Thread.sleep(2000);
		    driver.quit();
		    
		}
		  
		  @Test
		  public void testGoogleSite(){
			  driver.get(baseUrl);
			  //this one passes
		  WebElement el= driver.findElement(By.id("lst-ib"));
			  System.out.println("lst-ib is enabled" + el.isEnabled());
			  driver.findElement(By.id("lst-ib")).sendKeys("I am a winner");
			  //or
			//  el.sendKeys("I am a winner");

//			  // This one didn't work as id for different browsers are different
////		  WebElement e2= driver.findElement(By.id("gs_taif0"));
////			  System.out.println(" gs_taif0 is enabled" + e2.isEnabled());
////			  driver.findElement(By.id("gs_taif0")).sendKeys("I am a winner");
//
////			  
////
//		  WebElement e3= driver.findElement(By.id("gs_htif0"));
//			  System.out.println("gs_htif0 is enabled" + e3.isEnabled());
//			  driver.findElement(By.id("gs_htif0")).sendKeys("I am a winner");
//
////			  


			  
		  }
	}

