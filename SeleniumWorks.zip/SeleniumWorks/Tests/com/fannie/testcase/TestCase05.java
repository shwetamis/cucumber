package com.fannie.testcase;

import static org.junit.Assert.*;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestCase05 {

	private WebDriver driver;
	  private String baseUrl;
	  
	  @Before
	  public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chrome\\chromedriver_win32\\chromedriver.exe");
	    driver = new ChromeDriver();
	    baseUrl = "http://naveenks.com/selenium/RegForm.html";

	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	  }
	  
	  @After
	  public void tearDown() throws Exception {
		  Thread.sleep(2000);
	    driver.quit();
	    
	}
// Test to test the form by Submit button value	  
	  @Test
	  public void getSubmitBtnVal() throws InterruptedException{
		  //loads web page or web url
		  driver.get(baseUrl);
		///html/body/div[1]/form/br
		  WebElement element1= driver.findElement(By.xpath("html/body/div[1]/form/div[13]"));
				  
		String elementText= element1.getAttribute("value");
		System.out.println(" Element Text is: " + elementText);
				 
		  
	  }

}
