package com.fannie.testcase;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestCase01 {
	 private WebDriver driver;
	  private String baseUrl;
	  
	  @Before
	  public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chrome\\chromedriver_win32\\chromedriver.exe");
	    driver = new ChromeDriver();
	    baseUrl = "http://naveenks.com/selenium/RegForm.html";

	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	  }
	  
	  
	  @After
	  public void tearDown() throws Exception {
		  Thread.sleep(2000);
	    driver.quit();
	    
	}
	  @Test
	  public void navigateTest() throws InterruptedException{
		  driver.get(baseUrl);
		  System.out.println("Title"+ driver.getTitle());
		  String currentURL= driver.getCurrentUrl();
		  System.out.println("Current URL is :" + currentURL);
		 //navigate to another page 
		  driver.navigate().to("http://naveenks.com/selenium/LoginForm.html");
		  currentURL=driver.getCurrentUrl();
		  System.out.println("Current URL is :" + currentURL);
		  Thread.sleep(2500);	
		  // go back to the previous page
		  driver.navigate().back();
		  Thread.sleep(1000);
		  // refresh the page
		  driver.navigate().refresh();
		  System.out.println("page" + driver.getCurrentUrl()+ "refreshed");
		  // now move forward
		  driver.navigate().forward();
		  System.out.println("After forward" + driver.getCurrentUrl());
		  
		  
		  System.out.println(".........................................");
		  System.out.println(driver.getPageSource());// this will give full source code of a page
	 
 }
}
