package com.fannie.implicitexplicit;

import static org.junit.Assert.*;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.fannie.utils.WaitTypes;

public class ExplicitWaitGeneric {
	private WebDriver driver;
	private String baseUrl;
	private WaitTypes wt;
	@Before
	  public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chrome\\chromedriver_win32\\chromedriver.exe");// this is the location where your driver is
	    driver = new ChromeDriver();
	    baseUrl = "http://naveenks.com/selenium/LoginForm.html";
	    wt=new WaitTypes(driver);
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);//wait for 30 secs, if this is commented out the test fails as after login email page won't stay
	  }
	  @After
	  public void tearDown() throws Exception {
		  Thread.sleep(2000);
	    driver.quit(); // quit the website after performing the function
	    
	} 
	  
	  @Test
	  public void test() throws InterruptedException{
		  driver.get(baseUrl);
		  
		  WebElement email = wt.waitForElement(By.id("uname"), 5);
		  email.sendKeys("shweta@tetsing.com");
		  WebElement pwd = wt.waitForElement(By.id("pwd"), 6);
		  pwd.sendKeys("testing123");
		  wt.clickWhenReady(By.id("submitBtn"), 3);
	  }
	  


}
