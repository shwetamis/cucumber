package com.fannie.pomexec;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.fannie.pom.DriverFactory;

public class FindLinksTest {

	private static WebDriver driver;
	private String baseUrl;

	@BeforeClass
	public static void beforeClass() {
		driver = DriverFactory.getDriver("chrome");// loads the driver by
													// calling class driver
	}

	@After
	public void tearDown() throws Exception {
		Thread.sleep(3000);
		driver.quit(); // quit the website after performing the function

	}

	@Before
	public void setup() {
		baseUrl = "http://expedia.com";
		driver.get(baseUrl);
	}

	@Test
	public void test() throws MalformedURLException {
	// implementation for getting all the links will be here
		
		List<WebElement> list =clickableLinks();
		for (WebElement temp:list){
			//System.out.println(temp.getText());
			String href = temp.getAttribute("href");
			System.out.println("URL is" +href + "response is : "+linkStatus(new URL(href)));
		}
		
	}
	// this will look for all elements in given page store all  "a" and img and if it has href
	public static List<WebElement> clickableLinks(){
		List<WebElement> linksToClick = new ArrayList<WebElement>();
		
		List<WebElement> anchorElements = driver.findElements(By.tagName("a"));
		anchorElements.addAll(driver.findElements(By.tagName("img")));
		
		// all tags with href
		
		for(WebElement temp : anchorElements){
			
			if(temp.getAttribute("href")!=null){
			linksToClick.add(temp);
		 }
		}
		 return  linksToClick;
	}
    
	public static String linkStatus(URL url){
		
		//alt + shift +z --> for try catch block
	
	try {
		HttpURLConnection httpconnection =(HttpURLConnection)url.openConnection();
		
		httpconnection.connect();
		String responseMessage =httpconnection.getResponseMessage();
		httpconnection.disconnect();
		return responseMessage;
	} catch (IOException e) {
		// TODO Auto-generated catch block
		return e.getMessage();
	}
	
}

	
	
}