package com.fannie.screenshots;

import static org.junit.Assert.*;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.WebDriver;

import com.fannie.pom.DriverFactory;
import com.fannie.pom.FlightPagePOMFactory;
import com.fannie.utils.ScreenShot;

public class POMTest02 {
	private static WebDriver driver;
	private FlightPagePOMFactory flightFactory;
	private String baseUrl;

	@BeforeClass
	public static void beforeClass() {
		driver = DriverFactory.getDriver("chrome");// loads the driver by // calling class driver
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);									
	}

	@After
	public void tearDown() throws Exception {
		Thread.sleep(3000);
		// screen shot before you quit
		String fileName ="sample";
		ScreenShot.takeScreenShot(driver, fileName);
		driver.quit(); // quit the website after performing the function

	}

	@Before

	public void setup() {
		flightFactory = new FlightPagePOMFactory(driver);
		baseUrl = "http://expedia.com";
		driver.get(baseUrl);
	}

	@Test
	public void test() {
		flightFactory.clickFlightTab();
		flightFactory.sendFlyingFrom("Washington, DC (WAS-All Airports)");
		flightFactory.sendFlyingTo("Chennai, India");
		flightFactory.sendDepartingDate("3/15/2017");
		flightFactory.sendReturnDate("4/15/2017");
		flightFactory.clickSearchBtn();
	}

}
