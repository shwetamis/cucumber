package com.fannie.screenshots;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.fannie.pom.DriverFactory;
import com.fannie.utils.ScreenShot;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class LoginReportTest {
	private static WebDriver driver;
	private String baseUrl;
	
	//report variables --> report handler and will store the reports
	private ExtentReports report;
	//creates the logs
	private ExtentTest test;
	

	@BeforeClass
	public static void beforeClass() {
		driver = DriverFactory.getDriver("chrome");// loads the driver by
	}

	@After
	public void tearDown() throws Exception {
		Thread.sleep(3000);
		//driver.quit(); // quit the website after performing the function
report.endTest(test);
report.flush();
	}

	@Before
	public void setup() {
		baseUrl = "http://cinetalenters.com/#/login";
		String filePath="C:\\Users\\Huser\\Desktop\\reports\\LoginReportTest.html";
		//report = new ExtentReports(filePath);
		
		// to avoid overriding previous report
		report = new ExtentReports(filePath,false);
		
		
		test=report.startTest("verify login for user");
		test.log(LogStatus.INFO, "before loading base url");
		 driver.manage().window().maximize();
			test.log(LogStatus.INFO, "After max win");
		driver.get(baseUrl);
		
	}

	@Test
	public void test() throws IOException {
		
		WebElement email = driver.findElement(By.id("email"));
		email.sendKeys("adith.naveen@gmail.com");
		test.log(LogStatus.INFO, "username send to server");
		
		WebElement password = driver.findElement(By.id("password"));
		password.sendKeys("secret123");
		//password.sendKeys("secret@123");
		test.log(LogStatus.INFO, "password send to server");
		
		
		WebElement subBtn=
				driver.findElement(By.xpath("/html/body/div[2]/div/div/div/form/div[3]/div/button"));
		subBtn.click();
		test.log(LogStatus.INFO, "Clicked on submit btnr");
		
		/// to see acknowledgment message
		
		//dashBoard is web element from where we are extracting message	
		
		// try catch block will capture the exception and put it in the report
		WebElement dashBoard= null;
		try{
			dashBoard=driver.findElement
					(By.xpath("/html/body/div[2]/div/div/div[2]/div[3]/div[1]/p[2]"));// X path of the message "Hi Naveen Kumar" on webpage after successfull login"
				} catch(Exception ex){
					
					test.log(LogStatus.FAIL, "Sorry User not logged in");
					// to capture screen shot
					String path =ScreenShot.takeScreenShot(driver, "Loginfail");
					
					String imagePath =test.addScreenCapture(path);
					test.log(LogStatus.FAIL, "Welcome message fail-->",imagePath);
				}
				String dashBoardMessage = dashBoard.getText();
				System.out.println("Message from server is-->" +dashBoardMessage);
				
				if(dashBoardMessage!=null){
					System.out.println("Messgae From Server-->"+dashBoardMessage);
					test.log(LogStatus.PASS, "User successfully logged in");
				}else {
					test.log(LogStatus.FAIL, "Sorry User not logged in");
			}
				
	}



@Test
public void testagain(){
	test.log(LogStatus.ERROR, " Throws an err",new RuntimeException("Some messgae thrown"));
}


@Test
public void testagain2(){

	test.log(LogStatus.PASS, " Hey I am pass");
}


}