import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

//program to test drop down
public class TestCase04 {


	private WebDriver driver;
	  private String baseUrl;
	  private String baseURL1;
	  
	  @Before
	  public void setUp() throws Exception {
		System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chrome\\chromedriver_win32\\chromedriver.exe");
	    driver = new ChromeDriver();
	    baseUrl = "https://www.expedia.com";
	    baseURL1="http://html.com/attributes/select-multiple/";

	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	  }
	  
	  @After
	  public void tearDown() throws Exception {
		  Thread.sleep(2000);
	    driver.quit();
	    
	}
	  @Ignore
	  @Test
	  public void roomTest(){
		  driver.get(baseUrl);
		  //select by rooms
		  WebElement element1 = driver.findElement(By.id("package-rooms-hp-package"));
		  Select select1 =new Select(element1);
		  List<WebElement> options = select1.getOptions();
		  
		  System.out.println(" Number of option for element 1 -->" + options.size());
		  
		  for(int i =0 ; i<options.size() ; i++){
			  System.err.println(select1.getOptions().get(i).getText());
		  }
		  // select by val
		  select1.selectByValue("2");// values will take in string fashion,  it will select 2 from the list
		  //select by index
		  select1.selectByIndex(2);//value in int fashion and it will select 3 from the list
	  }


@Test
public void multiSelectTEst() throws InterruptedException{
	driver.get(baseURL1);
	
	////*//*[@id="wrapper"]/article/section/div[2]/select
	Select select = new
			Select(driver.findElement(By.xpath
					("//*[@id='wrapper']/article/section/div[2]/select")));
	
	select.selectByValue("American");
	select.selectByValue("Greater");
	
	Thread.sleep(3000);
	select.deselectByValue("American");
	Thread.sleep(1000);
	select.deselectByValue("Greater");
	Thread.sleep(2000);
	select.selectByIndex(2);
}







}